// app/api/transatel/sim/serial/[iccid]/route.ts
//
// GET /api/transatel/sim/serial/{iccid}
//
// Server-side proxy to Transatel's SIM lookup:
//   https://api.transatel.com/sim-management/sims/api/esims/sim-serial/{iccid}
//
// The bearer token comes from getTransatelToken() (client-credentials flow,
// cached). Kept on the server so credentials never reach the browser and the
// call isn't blocked by CORS.

import { NextRequest, NextResponse } from "next/server";
// Adjust this import to your path alias if needed (e.g. relative path).
import { getTransatelToken, TransatelAuthError } from "../../../../../utils/transatelToken";

const TRANSATEL_BASE =
  process.env.TRANSATEL_API_BASE_URL || "https://api.transatel.com";

/** Call the sim-serial endpoint with a bearer token. */
async function lookupSim(iccid: string, token: string): Promise<Response> {
  const upstreamUrl = new URL(
    `/sim-management/sims/api/esims/sim-serial/${encodeURIComponent(iccid)}`,
    TRANSATEL_BASE,
  );
  return fetch(upstreamUrl.toString(), {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${token}`,
    },
    cache: "no-store",
  });
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ iccid: string }> },
) {
  const { iccid } = await params;

  if (!iccid) {
    return NextResponse.json(
      { success: false, message: "ICCID is required." },
      { status: 400 },
    );
  }

  try {
    let token = await getTransatelToken();
    let upstreamRes = await lookupSim(iccid, token);

    // Token expired/revoked between cache and call — refresh once and retry.
    if (upstreamRes.status === 401) {
      token = await getTransatelToken(true);
      upstreamRes = await lookupSim(iccid, token);
    }

    const detail = await upstreamRes.json().catch(() => ({}));

    return NextResponse.json(
      { success: upstreamRes.ok, iccid, detail },
      { status: upstreamRes.status },
    );
  } catch (err) {
    if (err instanceof TransatelAuthError) {
      return NextResponse.json(
        { success: false, iccid, message: err.message },
        { status: 500 },
      );
    }
    console.error(`❌ Transatel sim-serial lookup failed for ${iccid}:`, err);
    return NextResponse.json(
      { success: false, iccid, message: "Could not reach Transatel." },
      { status: 502 },
    );
  }
}